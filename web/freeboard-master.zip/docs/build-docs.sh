#!/bin/bash

docco --css docco-fb.css ./../examples/plugin_example.js --output ./